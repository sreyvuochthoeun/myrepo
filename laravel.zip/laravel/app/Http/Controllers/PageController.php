<?php
/**
 * Created by PhpStorm.
 * User: senghok
 * Date: 12/6/2016
 * Time: 4:21 PM
 */
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use stdClass;
use WhatsapiTool;
use Xaamin\Whatsapi\Facades\Laravel\Whatsapi;

class PageController extends Controller
{
    public function index()
    {
//        $number = '85516393666'; # Number with country code
//        $type = 'sms'; # This can be either sms or voice
//        $response = WhatsapiTool::requestCode($number, $type);
//        print_r($response);
//        $code = '133980'; # Replace with received code
//        $response = WhatsapiTool::registerCode($number, $code);
//        print_r($response);
        $user = new stdClass;
        $user->name = 'test';
        $user->phone = '85516393666';
        $message = "test";
        $messages = Whatsapi::send($message, function ($send) use ($user) {
            $send->to($user->phone);
            $send->message('Thanks for subscribe');
        });
    }
}