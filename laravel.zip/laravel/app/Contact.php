<?php
/**
 * Created by PhpStorm.
 * User: senghok
 * Date: 12/5/2016
 * Time: 10:28 AM
 */
namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    function tags()
    {
        return $this->hasMany('App\Tag');
    }
}