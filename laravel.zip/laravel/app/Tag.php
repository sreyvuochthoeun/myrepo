<?php
/**
 * Created by PhpStorm.
 * User: senghok
 * Date: 12/5/2016
 * Time: 10:29 AM
 */
namespace App;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    
}