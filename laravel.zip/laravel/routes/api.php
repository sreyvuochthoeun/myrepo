<?php

use App\Contact;
use App\Tag;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('contacts/{id?}', function ($id = null) {
    return $id ? Contact::find($id) : Contact::all();
});
Route::post('contacts', function (Request $request) {
    $contact = new Contact();
    $contact->owner = $request->owner;
    $contact->name = $request->name;
    $contact->tel = $request->tel;
    $contact->save();
    return $contact;
});
Route::put('contacts/{id}', function ($id, Request $request) {
    $contact = Contact::find($id);
    $contact->owner = $request->owner;
    $contact->name = $request->name;
    $contact->tel = $request->tel;
    $contact->save();
    return $contact;
});
Route::delete('contacts/{id}', function ($id) {
    return Contact::destroy($id);
});
Route::get('contacts/{id}/tags', function ($id) {
    return Contact::find($id)->tags;
});
Route::get('tags/{id}', function ($id) {
    return Tag::find($id);
});
Route::post('tags', function (Request $request) {
    $contact = new Tag();
    $contact->contact_id = $request->contact_id;
    $contact->name = $request->name;
    $contact->rate = $request->rate;
    $contact->save();
    return $contact;
});
Route::put('tags/{id}', function ($id, Request $request) {
    $contact = Tag::find($id);
    $contact->contact_id = $request->contact_id;
    $contact->name = $request->name;
    $contact->rate = $request->rate;
    $contact->save();
    return $contact;
});
Route::delete('tags/{id}', function ($id) {
    return Tag::destroy($id);
});