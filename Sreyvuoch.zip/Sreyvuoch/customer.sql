-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2017 at 05:10 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customer_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `td_customer`
--

CREATE TABLE IF NOT EXISTS `td_customer` (
  `cus_id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_first_name` varchar(50) NOT NULL DEFAULT '0',
  `cus_last_name` varchar(50) NOT NULL DEFAULT '0',
  `cus_gender` varchar(1) NOT NULL DEFAULT '0',
  `cus_email_address` varchar(50) NOT NULL DEFAULT '0',
  `cus_dob` date NOT NULL DEFAULT '0000-00-00',
  `cus_address` varchar(200) NOT NULL DEFAULT '0',
  `cus_phone` varchar(20) NOT NULL DEFAULT '0',
  `cus_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cus_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`cus_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `td_customer`
--

INSERT INTO `td_customer` (`cus_id`, `cus_first_name`, `cus_last_name`, `cus_gender`, `cus_email_address`, `cus_dob`, `cus_address`, `cus_phone`, `cus_created`, `cus_updated`) VALUES
(1, 'Sok', 'San', '0', 'Sokna@gmail.com', '1990-04-06', 'Phnom Penh', '012222555', '2016-12-12 00:00:00', '2017-01-24 23:05:20'),
(2, 'Dara', 'Dara', '0', 'Sokna@gmail.com', '1990-12-14', 'Phnom Penh', '0705555666', '2015-12-13 00:00:00', '2017-01-24 23:04:54'),
(3, 'Chan', 'Lina', '0', 'Sokna@gmail.com', '1992-01-16', 'Phnom Penh, Cambodia', '01233669', '2016-01-09 00:00:00', '2017-01-11 00:00:00'),
(4, 'Thear', 'Sokun', '1', 'Sokna@gmail.com', '1990-04-09', 'Kompung Cham', '01233669', '2016-01-09 00:00:00', '2017-02-12 00:00:00'),
(5, 'Sok', 'Suny', '0', 'Sokna@gmail.com', '1990-09-09', 'Kompung Chhnang', '01233669', '2015-03-09 00:00:00', '2017-01-24 23:05:45'),
(6, 'Chay', 'Chany', '1', 'Chany@gmail.com', '1990-03-04', 'Phnom Penh', '01233669', '2015-02-06 00:00:00', '2016-09-12 00:00:00');


-- --------------------------------------------------------

--
-- Table structure for table `td_user`
--

CREATE TABLE IF NOT EXISTS `td_user` (
  `use_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`use_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `td_user`
--

INSERT INTO `td_user` (`use_id`, `username`, `password`) VALUES
(1, 'admin', '123456');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
